'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('users', {
      id: { type: Sequelize.INTEGER, primaryKey: true, autoIncrement: true },
      firstName: Sequelize.STRING,
      lastName: Sequelize.STRING,
      maidenName: Sequelize.STRING,
      age: Sequelize.INTEGER,
      gender: Sequelize.STRING,
      email: { type: Sequelize.STRING, unique: true },
      phone: Sequelize.STRING,
      username: Sequelize.STRING,
      password: Sequelize.STRING,
      birthDate: Sequelize.STRING,
      image: Sequelize.STRING,
      bloodGroup: Sequelize.STRING,
      height: Sequelize.FLOAT,
      weight: Sequelize.FLOAT,
      eyeColor: Sequelize.STRING,
      hair: Sequelize.JSON,
      ip: Sequelize.STRING,
      address: Sequelize.JSON,
      macAddress: Sequelize.STRING,
      university: Sequelize.STRING,
      bank: Sequelize.JSON,
      company: Sequelize.JSON,
      ein: Sequelize.STRING,
      ssn: Sequelize.STRING,
      userAgent: Sequelize.STRING,
      crypto: Sequelize.JSON,
      role: Sequelize.STRING,
      createdAt: { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.literal('CURRENT_TIMESTAMP') },
      updatedAt: { type: Sequelize.DATE, allowNull: false, defaultValue: Sequelize.literal('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP') },
    });
  },

  async down(queryInterface) {
    await queryInterface.dropTable('users');
  },
};
