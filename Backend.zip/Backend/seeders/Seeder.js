'use strict';

const axios = require('axios');

module.exports = {
  async up(queryInterface, Sequelize) {
    try {
      const response = await axios.get('https://dummyjson.com/users');
      const users = response.data.users;
      const formattedUsers = users.map(user => ({
        firstName: user.firstName,
        lastName: user.lastName,
        maidenName: user.maidenName,
        age: user.age,
        gender: user.gender,
        email: user.email,
        phone: user.phone,
        username: user.username,
        password: user.password,
        birthDate: user.birthDate,
        image: user.image,
        bloodGroup: user.bloodGroup,
        height: user.height,
        weight: user.weight,
        eyeColor: user.eyeColor,
        hair: JSON.stringify(user.hair),
        ip: user.ip,
        address: JSON.stringify(user.address),
        macAddress: user.macAddress,
        university: user.university,
        bank: JSON.stringify(user.bank),
        company: JSON.stringify(user.company),
        ein: user.ein,
        ssn: user.ssn,
        userAgent: user.userAgent,
        crypto: JSON.stringify(user.crypto),
        role: user.role,
        createdAt: new Date(),
        updatedAt: new Date(),
      }));

      await queryInterface.bulkInsert('users', formattedUsers, {});
      console.log('Users seeded successfully from API!');
    } catch (error) {
      console.error('Error fetching or inserting users:', error);
    }
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.bulkDelete('users', null, {});
  },
};
