const express = require('express');
const { User } = require('./models');
const sequelize = require('./config/Database');
const PORT = process.env.PORT || 5000;
const app = express();
app.use(express.json());

(async () => {
  try {
    await sequelize.authenticate();
    console.log(' Database Connection has been established successfully.');
  } catch (error) {
    console.error(' Unable to connect to the database:', error);
  }
})();

app.get('/', (req, res) => {
  res.status(200).json({ status: 'ok', msg: `Please visit http://localhost:5000/users to see the list of users` });
});

app.get('users', async (req, res) => {
  try {
    const users = await User.findAll();
    res.status(200).json({status:"ok",Limit:users.length || 0 ,usersData: users });
  } catch (err) {
    console.error('Error fetching users:', err);
    res.status(500).json({status:"failed", error: 'Internal Server Error' });
  }
});

app.listen(PORT, () => {
  console.log(` Server running on http://localhost:${PORT}`);
    console.log(` Click here to Fetch Users data =>  http://localhost:${PORT}/users`);

});

