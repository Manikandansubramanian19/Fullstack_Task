module.exports = (sequelize, DataTypes) => {
  return sequelize.define(
    'User',
    {
      firstName: DataTypes.STRING,
      lastName: DataTypes.STRING,
      maidenName: DataTypes.STRING,
      age: DataTypes.INTEGER,
      gender: DataTypes.STRING,
      email: { type: DataTypes.STRING, unique: true },
      phone: DataTypes.STRING,
      username: DataTypes.STRING,
      password: DataTypes.STRING,
      birthDate: DataTypes.STRING,
      image: DataTypes.STRING,
      bloodGroup: DataTypes.STRING,
      height: DataTypes.FLOAT,
      weight: DataTypes.FLOAT,
      eyeColor: DataTypes.STRING,
      hair: DataTypes.JSON,
      ip: DataTypes.STRING,
      address: DataTypes.JSON,
      macAddress: DataTypes.STRING,
      university: DataTypes.STRING,
      bank: DataTypes.JSON,
      company: DataTypes.JSON,
      ein: DataTypes.STRING,
      ssn: DataTypes.STRING,
      userAgent: DataTypes.STRING,
      crypto: DataTypes.JSON,
      role: DataTypes.STRING,
    },
    {
      tableName: 'users',
      timestamps: true,
    }
  );
};
