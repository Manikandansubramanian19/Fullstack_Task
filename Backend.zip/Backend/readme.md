# Node.js Backend API for Users

A simple Node.js API using **Express** and **Sequelize** to serve a mockup user list stored in a **MySQL** database.  
The API mimics the structure of users from [DummyJSON Users API](https://dummyjson.com/users).

---

## Features

- Fetch a list of users from a MySQL database.
- Sequelize ORM for secure and maintainable database interactions.
- Environment variable configuration for sensitive data.
- Graceful error handling.
- Supports migrations and seeders.

---

## Prerequisites

- Node.js v18+
- MySQL Server
- update .env based on your mysql db name , password , username
- npm


## Steps to do
- Step 1 : npm update
- Step 2 : npm run migrate
- Step 3 : npm run seed
- Step 4 : npm run dev

- .env.example
## What Has Been Implemented

## Sequelize ORM for Users:

- Created a User model with fields like firstName, lastName, email, username, password, age, gender, address, company, bank, - - hair, crypto, and role.

Complex fields like address, bank, company, hair, crypto are stored as JSON.

## Database Migration:

Created migration files to generate the Users table in MySQL.

## Seeder:

Implemented a seeder that fetches data from https://dummyjson.com/users?limit=10 and populates the database.

## Express API Endpoints:

/ → Base route returns a welcome message.

/users → Fetches all users from the database.

## Error Handling:

Graceful handling of database connectivity issues and API errors.

## Environment Variables:

All sensitive information (DB credentials, PORT) is stored in .env.
